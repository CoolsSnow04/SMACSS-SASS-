Sass + SMACSS
==============

To organize your Sass project with SMACSS organisation. Inspired by SMACSS from Jonathan Snook. To know more, go to : http://smacss.com

You can use it with any framework like Bootstrap or Foundation (to put in scss/vendor and override it in vendor-override)

Based on
==
 - Idiomatic css
 - POPY-starter-HTML-SCSS

Team
==
Jonathan Path @jonathanpath / http://jonathanpath.com

Laurent Sutterlity @sutterlity / http://sutterlity.fr
